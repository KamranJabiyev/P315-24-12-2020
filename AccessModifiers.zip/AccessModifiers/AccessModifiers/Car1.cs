﻿namespace Demo
{
    class Car
    {

    }

    class Person 
    {
        public int Demo { get; set; }
    }

    class Animal
    {

    }
}

namespace Demo.Test
{
    class Transport
    {

    }


}

namespace Demo1
{
    class Person
    {
        public int Demo1 { get; set; }
    }
}
