﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryP315;
using Demo;
using Demo.Test;
using Demo1;

namespace AccessModifiers
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Access modifiers
            #region Public - class, all class members
            //Car car = new Car("BMW","X5");
            //car.Brand = "Mercedes";
            //car.Info();
            //Console.WriteLine(car.Brand);
            #endregion

            #region Private - all class members
            //Car car = new Car("BMW", "X5",200);
            //car.Brand = "test";

            //car.Speed = 500;
            //Console.WriteLine(car.Speed);
            //car.SetSpeed(500);
            //Console.WriteLine(car.GetSpeed());
            //car.GetSpeed();
            //Console.WriteLine(car._speed);
            #endregion

            #region Protected - all class members
            //Car car = new Car("BMW", "X5", 200);
            #endregion

            #region Public readonly - field
            //Car car = new Car("BMW", "X5", 200);
            //Console.WriteLine(car.Color);
            #endregion

            #region Private readonly - field
            //Car car = new Car("BMW", "X5", 200);
            #endregion

            #region Internal -class(default),all members
            //Notification notify = new Notification();

            #endregion

            #region protected internal - all class members
            //protected - referenced assembly
            //internal - same assembly
            //Notification notify = new Notification();
            #endregion

            #region private protected - all class members
            //protected - same assembly
            //private - referenced assembly
            #endregion
            #endregion

            #region Namespace
            //Car car = new Car();
            //Demo.Car car1 = new Demo.Car();
            //Demo1.Person person = new Demo1.Person();
            //Animal animal = new Animal();
            //Car car = new Car();
            //Transport transport = new Transport();
            #endregion

            #region static
            //Person.Count = 10;
            //Console.WriteLine(Person.Count);
            //Person.Print();
            Person.Count = 10;
            Person p1 = new Person("Fikret", "Cavadov");
            Person p2 = new Person("Cavid", "Mecidov");
            Person p3 = new Person("", "");
            //Console.WriteLine(Person.Count);
            Console.WriteLine(p1.Number);
            Console.WriteLine(p2.Number);
            Console.WriteLine(p3.Number);
            #endregion
        }
    }

    #region static
    class Person
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public static int Count=0;
        public int Number=0;

        //static ctor -klasin ilk uzvunun istifadesi zamani ishe dushur.Hech bir parametr qebul etmir!!!
        static Person()
        {
            Console.WriteLine("First person created");
        }
        public Person(string name,string surname)
        {
            Name = name;
            Surname = surname;
            Count++;
            Number=Count;
        }

        //public static void Print()
        //{
        //    Count = 10;
        //    Console.WriteLine($"static method {Count}");
        //}

        //public void Show()
        //{
        //    Count++;
        //    Print();
        //}
    }

    //static class - all members must be static, can not get instance.Can not get inheretance and extend
    static class Test
    {
        public static int MyProperty { get; set; }
        private static string test; 
        static Test()
        {

        }
    }
    #endregion

    #region Internal -class(default),all members
    //class Test : Notification
    //{
    //    public Test()
    //    {
    //        Text = "Sagol";
    //        Console.WriteLine(Text);
    //    }
    //}
    #endregion
}
