﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryP315
{
    public class Notification
    {
        public string Title { get; set; }
        protected internal string Text { get; set; }
        private protected int Count { get; set; }
    }

    internal class Message : Notification
    {
        public Message()
        {
            Text = "Salam";
            Console.WriteLine(Text);
            Count = 10;
            Console.WriteLine(Count);
        }
    }

    class Addnotify
    {
        
        public Addnotify()
        {
            Notification notification = new Notification();
            notification.Text = "";
            Console.WriteLine(notification.Text);
        }
    }
}
